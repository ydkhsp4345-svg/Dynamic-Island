package com.ada.island

import android.app.PendingIntent
import android.graphics.drawable.Drawable

class Item(
    val key: String, val pkg: String, val title: String, val text: String,
    val icon: Drawable?, val intent: PendingIntent?
) { var expireAt = 0L }

object Bus {
    var post: ((Item) -> Unit)? = null
    var remove: ((String) -> Unit)? = null
}
