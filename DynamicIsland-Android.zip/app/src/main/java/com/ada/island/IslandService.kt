package com.ada.island

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import android.text.TextUtils
import android.view.GestureDetector
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class IslandService : Service() {
    companion object { @Volatile var running = false }

    // mode: 1 media, 2 notification, 3 temporary, 4 call, 5 idle clock
    private class Show(
        val icon: Drawable?, val title: String, val sub: String,
        val progress: Int, val mode: Int, val compact: String, val playing: Boolean = false
    )

    private val h = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var pill: LinearLayout
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var icon: ImageView
    private lateinit var title: TextView
    private lateinit var sub: TextView
    private lateinit var bar: ProgressBar
    private lateinit var btns: LinearLayout
    private val allBtns = ArrayList<TextView>()
    private lateinit var bPrev: TextView
    private lateinit var bPlay: TextView
    private lateinit var bNext: TextView
    private lateinit var bFlash: TextView
    private lateinit var bClear: TextView
    private lateinit var bOpen: TextView

    private val queue = ArrayList<Item>()
    private var cur = 0
    private var curMode = -1
    private var expanded = false
    private var attached = false
    private var screenOn = true
    private var battery = 0
    private var charging = false
    private var batInit = false
    private var lowWarned = false
    private var callState = TelephonyManager.CALL_STATE_IDLE
    private var tmpTitle = ""
    private var tmpSub = ""
    private var tmpProg = -1
    private var tmpUntil = 0L
    private var snoozeUntil = 0L
    private var ctl: MediaController? = null
    private var torch = false
    private var targetW = 0
    private var va: ValueAnimator? = null
    private var tcb: Any? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun pb(k: String) = Prefs.b(this, k)
    private fun pi(k: String) = Prefs.i(this, k)
    private fun hap() { if (::pill.isInitialized && pb("haptic")) pill.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startFg()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        running = true
        buildView()
        lp = WindowManager.LayoutParams(
            dp(140), dp(34),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL }

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction("android.media.VOLUME_CHANGED_ACTION")
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(rcv, f, Context.RECEIVER_EXPORTED) else registerReceiver(rcv, f)

        Bus.post = { item ->
            h.post {
                val nm = getSystemService(NotificationManager::class.java)
                if (pb("dnd") && nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL) return@post
                queue.removeAll { it.key == item.key }
                item.expireAt = System.currentTimeMillis() + pi("timeout") * 1000L
                queue.add(0, item)
                cur = 0
                snoozeUntil = 0
                render()
                hap()
            }
        }
        Bus.remove = { key -> h.post { queue.removeAll { it.key == key }; render() } }
        regCall()
        h.post(tick)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running) { if (tcb == null) regCall(); render() }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        h.removeCallbacksAndMessages(null)
        Bus.post = null
        Bus.remove = null
        try { unregisterReceiver(rcv) } catch (e: Exception) {}
        unregCall()
        if (::pill.isInitialized) detach()
        super.onDestroy()
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ada", "AdaIsland", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "ada")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("AdaIsland")
            .setContentText(t("Çalışıyor", "Running"))
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    // ---------- UI ----------
    private fun mk(label: String, f: () -> Unit): TextView {
        val tv = TextView(this)
        tv.text = label
        tv.textSize = 20f
        tv.gravity = Gravity.CENTER
        tv.setPadding(dp(14), dp(6), dp(14), dp(6))
        tv.setOnClickListener { hap(); f() }
        allBtns.add(tv)
        btns.addView(tv)
        return tv
    }

    private fun buildView() {
        pill = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        icon = ImageView(this)
        icon.scaleType = ImageView.ScaleType.CENTER_CROP
        top.addView(icon, LinearLayout.LayoutParams(dp(22), dp(22)).apply { rightMargin = dp(8) })
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        title = TextView(this).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END; typeface = Typeface.DEFAULT_BOLD }
        sub = TextView(this).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END }
        col.addView(title)
        col.addView(sub)
        top.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        pill.addView(top, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        pill.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(4)).apply { topMargin = dp(6) })
        btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        pill.addView(btns, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        bPrev = mk("⏮") { ctl?.transportControls?.skipToPrevious() }
        bPlay = mk("▶") {
            if (ctl?.playbackState?.state == PlaybackState.STATE_PLAYING) ctl?.transportControls?.pause()
            else ctl?.transportControls?.play()
        }
        bNext = mk("⏭") { ctl?.transportControls?.skipToNext() }
        bFlash = mk("🔦") { toggleTorch() }
        bClear = mk("🗑") { clearCur() }
        bOpen = mk("↗") { openCur() }

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                hap()
                if (pb("tapexp")) { expanded = !expanded; render() } else openCur()
                return true
            }
            override fun onLongPress(e: MotionEvent) {
                hap()
                this@IslandService.startActivity(Intent(this@IslandService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (!pb("swipe")) return false
                if (Math.abs(vy) > Math.abs(vx)) {
                    if (vy < 0) { if (expanded) expanded = false else dismiss() }
                } else if (queue.size > 1) {
                    cur = (cur + (if (vx < 0) 1 else queue.size - 1)) % queue.size
                    queue[cur].expireAt = System.currentTimeMillis() + pi("timeout") * 1000L
                }
                render()
                return true
            }
        })
        pill.setOnTouchListener { _, ev -> gd.onTouchEvent(ev) }
    }

    private fun applyStyle() {
        val a = pi("opacity") * 255 / 100
        val g = GradientDrawable()
        g.setColor((a shl 24) or (Prefs.bg(this) and 0xFFFFFF))
        g.cornerRadius = dp(pi("radius") + if (expanded) 8 else 0).toFloat()
        pill.background = g
        val v = if (expanded) 12 else 4
        pill.setPadding(dp(12), dp(v), dp(12), dp(v))
        val fg = Prefs.fg(this)
        title.setTextColor(fg)
        sub.setTextColor((fg and 0xFFFFFF) or 0xB3000000.toInt())
        title.textSize = pi("textsize").toFloat()
        sub.textSize = (pi("textsize") - 2).toFloat()
        for (b in allBtns) b.setTextColor(fg)
        bar.progressTintList = android.content.res.ColorStateList.valueOf(fg)
    }

    // ---------- content ----------
    private fun compute(now: Long): Show? {
        if (now < snoozeUntil) return null
        if (callState != TelephonyManager.CALL_STATE_IDLE && pb("call")) {
            val ti = if (callState == TelephonyManager.CALL_STATE_RINGING) t("Gelen arama", "Incoming call") else t("Görüşmede", "On call")
            return Show(null, ti, "📞", -1, 4, "📞 $ti")
        }
        if (now < tmpUntil) return Show(null, tmpTitle, tmpSub, tmpProg, 3, "$tmpTitle  $tmpSub")
        if (pb("notif") && queue.isNotEmpty()) {
            val n = queue[cur]
            val priv = pb("privacy")
            val ti = if (priv) t("Yeni bildirim", "New notification") else n.title
            val tx = if (priv) "" else n.text
            return Show(n.icon, ti, tx, -1, 2, if (tx.isEmpty()) ti else "$ti: $tx")
        }
        if (pb("media")) mediaShow()?.let { return it }
        if (pb("always")) {
            val f = (if (pb("h24")) "HH:mm" else "hh:mm") + (if (pb("sec")) ":ss" else "") + (if (pb("h24")) "" else " a")
            val time = SimpleDateFormat(f, Locale.getDefault()).format(Date())
            val bt = if (pb("battery")) (if (charging) "⚡ " else "🔋 ") + battery + "%" else ""
            return Show(null, time, bt, -1, 5, if (bt.isEmpty()) time else "$time  $bt")
        }
        return null
    }

    private fun findCtl(): MediaController? = try {
        val msm = getSystemService(MediaSessionManager::class.java)
        val list = msm.getActiveSessions(ComponentName(this, NotifListener::class.java))
        list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list.firstOrNull()
    } catch (e: Exception) { null }

    private fun mediaShow(): Show? {
        val c = ctl ?: return null
        val st = c.playbackState ?: return null
        val playing = st.state == PlaybackState.STATE_PLAYING
        if (!playing && !expanded) return null
        val md = c.metadata ?: return null
        val ti = md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return null
        val ar = md.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        val dur = md.getLong(MediaMetadata.METADATA_KEY_DURATION)
        var pos = st.position
        if (playing) pos += ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
        val prog = if (dur > 0) (pos * 100 / dur).toInt().coerceIn(0, 100) else -1
        val bmp = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
        val ic: Drawable? = if (bmp != null) BitmapDrawable(resources, bmp) else null
        return Show(ic, ti, ar, prog, 1, if (ar.isEmpty()) "♪ $ti" else "♪ $ti – $ar", playing)
    }

    private fun render() {
        if (!::pill.isInitialized) return
        val now = System.currentTimeMillis()
        if (!expanded && pb("autohide")) queue.removeAll { it.expireAt < now }
        if (cur >= queue.size) cur = 0
        val s = compute(now)
        curMode = s?.mode ?: -1
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        if (s == null || !screenOn || (land && pb("hideland"))) { expanded = false; detach(); return }

        applyStyle()
        if (pb("appicon") && s.icon != null) { icon.setImageDrawable(s.icon); icon.visibility = View.VISIBLE }
        else icon.visibility = View.GONE
        title.text = if (expanded) s.title else s.compact
        sub.text = s.sub
        sub.visibility = if (expanded && s.sub.isNotEmpty()) View.VISIBLE else View.GONE
        val showBar = expanded && s.progress >= 0 && pb("progress")
        bar.visibility = if (showBar) View.VISIBLE else View.GONE
        bar.progress = s.progress.coerceAtLeast(0)
        btns.visibility = if (expanded) View.VISIBLE else View.GONE
        val med = s.mode == 1
        val ntf = s.mode == 2 && pb("clearbtn")
        bPrev.visibility = if (med) View.VISIBLE else View.GONE
        bPlay.visibility = if (med) View.VISIBLE else View.GONE
        bNext.visibility = if (med) View.VISIBLE else View.GONE
        bPlay.text = if (s.playing) "⏸" else "▶"
        bFlash.visibility = if (pb("flash")) View.VISIBLE else View.GONE
        bClear.visibility = if (ntf) View.VISIBLE else View.GONE
        bOpen.visibility = if (ntf) View.VISIBLE else View.GONE
        place()
    }

    private fun place() {
        val sw = resources.displayMetrics.widthPixels
        val tw = if (expanded) minOf(dp(pi("width")) * 2, sw - dp(16)) else dp(pi("width"))
        lp.height = if (expanded) WindowManager.LayoutParams.WRAP_CONTENT else dp(pi("height"))
        lp.y = dp(pi("yoff"))
        if (!attached) {
            lp.width = tw
            targetW = tw
            val an = pb("anim")
            pill.alpha = if (an) 0f else 1f
            pill.scaleX = if (an) 0.6f else 1f
            pill.scaleY = if (an) 0.6f else 1f
            try { wm.addView(pill, lp); attached = true } catch (e: Exception) { return }
            if (an) pill.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(pi("animms").toLong()).start()
        } else if (tw != targetW) {
            targetW = tw
            if (pb("anim")) {
                va?.cancel()
                val v = ValueAnimator.ofInt(lp.width, tw)
                v.duration = pi("animms").toLong()
                v.addUpdateListener {
                    lp.width = it.animatedValue as Int
                    try { wm.updateViewLayout(pill, lp) } catch (e: Exception) {}
                }
                va = v
                v.start()
            } else {
                lp.width = tw
                try { wm.updateViewLayout(pill, lp) } catch (e: Exception) {}
            }
        } else {
            try { wm.updateViewLayout(pill, lp) } catch (e: Exception) {}
        }
    }

    private fun detach() {
        va?.cancel()
        if (attached) {
            try { wm.removeView(pill) } catch (e: Exception) {}
            attached = false
        }
    }

    // ---------- actions ----------
    private fun openCur() {
        try { queue.getOrNull(cur)?.intent?.send() } catch (e: Exception) {}
        expanded = false
        render()
    }

    private fun clearCur() {
        queue.getOrNull(cur)?.let {
            NotifListener.instance?.cancelNotification(it.key)
            queue.remove(it)
        }
        expanded = false
        render()
    }

    private fun dismiss() {
        if (curMode == 2 && queue.isNotEmpty()) queue.removeAt(cur)
        else snoozeUntil = System.currentTimeMillis() + 10_000
    }

    private fun toggleTorch() {
        try {
            val cm = getSystemService(CameraManager::class.java)
            torch = !torch
            cm.setTorchMode(cm.cameraIdList[0], torch)
        } catch (e: Exception) { torch = false }
    }

    private fun tmp(ti: String, su: String, ms: Long, prog: Int = -1) {
        tmpTitle = ti; tmpSub = su; tmpProg = prog
        tmpUntil = System.currentTimeMillis() + ms
        render()
        hap()
        h.postDelayed({ render() }, ms + 50)
    }

    // ---------- system events ----------
    private val tick = object : Runnable {
        override fun run() {
            ctl = findCtl()
            render()
            h.postDelayed(this, 1000)
        }
    }

    private val rcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_BATTERY_CHANGED -> {
                    val lv = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
                    val sc = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                    battery = if (sc > 0) lv * 100 / sc else 0
                    val ch = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
                    if (batInit) {
                        if (ch && !charging && pb("charging")) tmp(t("Şarj oluyor", "Charging"), "⚡ $battery%", 3000)
                        if (!ch && battery <= 15 && !lowWarned && pb("lowbat")) {
                            lowWarned = true
                            tmp(t("Pil az", "Low battery"), "🪫 $battery%", 4000)
                        }
                    }
                    if (battery > 20) lowWarned = false
                    charging = ch
                    batInit = true
                }
                Intent.ACTION_SCREEN_ON -> { screenOn = true; render() }
                Intent.ACTION_SCREEN_OFF -> { screenOn = false; render() }
                "android.media.VOLUME_CHANGED_ACTION" -> {
                    if (pb("volume") && intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1) == 3) {
                        val v = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_VALUE", 0)
                        val mx = getSystemService(AudioManager::class.java).getStreamMaxVolume(3).coerceAtLeast(1)
                        tmp(t("Ses", "Volume"), "🔊 $v/$mx", 1500, v * 100 / mx)
                    }
                }
            }
        }
    }

    private fun regCall() {
        if (checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return
        try {
            val tm = getSystemService(TelephonyManager::class.java)
            if (Build.VERSION.SDK_INT >= 31) {
                val cb = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                    override fun onCallStateChanged(state: Int) { h.post { callState = state; render() } }
                }
                tm.registerTelephonyCallback(mainExecutor, cb)
                tcb = cb
            } else {
                val l = object : PhoneStateListener() {
                    override fun onCallStateChanged(state: Int, number: String?) { h.post { callState = state; render() } }
                }
                tm.listen(l, PhoneStateListener.LISTEN_CALL_STATE)
                tcb = l
            }
        } catch (e: Exception) {}
    }

    private fun unregCall() {
        try {
            val tm = getSystemService(TelephonyManager::class.java)
            val x = tcb ?: return
            if (Build.VERSION.SDK_INT >= 31 && x is TelephonyCallback) tm.unregisterTelephonyCallback(x)
            else if (x is PhoneStateListener) tm.listen(x, PhoneStateListener.LISTEN_NONE)
        } catch (e: Exception) {}
        tcb = null
    }
}
