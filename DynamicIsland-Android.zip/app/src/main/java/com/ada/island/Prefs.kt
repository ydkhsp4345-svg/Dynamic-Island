package com.ada.island

import android.content.Context
import java.util.Locale

fun t(tr: String, en: String) = if (Locale.getDefault().language == "tr") tr else en

class Sw(val key: String, val tr: String, val en: String, val def: Boolean)
class Sk(val key: String, val tr: String, val en: String, val min: Int, val max: Int, val def: Int)

object Prefs {
    val switches = listOf(
        Sw("notif", "Bildirimleri göster", "Show notifications", true),
        Sw("media", "Müzik kontrolü", "Music controls", true),
        Sw("battery", "Pil yüzdesi", "Battery percentage", true),
        Sw("charging", "Şarj animasyonu", "Charging popup", true),
        Sw("lowbat", "Düşük pil uyarısı", "Low battery warning", true),
        Sw("call", "Arama göstergesi", "Call indicator", true),
        Sw("volume", "Ses seviyesi göstergesi", "Volume indicator", true),
        Sw("always", "Boşta saat+pil göster (hep görünür)", "Idle clock+battery (always visible)", false),
        Sw("sec", "Saniyeyi göster", "Show seconds", false),
        Sw("h24", "24 saat biçimi", "24-hour clock", true),
        Sw("haptic", "Titreşim geri bildirimi", "Haptic feedback", true),
        Sw("autohide", "Otomatik gizle", "Auto hide", true),
        Sw("hideland", "Yatay modda gizle", "Hide in landscape", true),
        Sw("boot", "Açılışta başlat", "Start on boot", true),
        Sw("dnd", "Rahatsız Etme'ye uy", "Respect Do Not Disturb", true),
        Sw("tapexp", "Dokununca genişlet", "Tap to expand", true),
        Sw("swipe", "Kaydırma hareketleri", "Swipe gestures", true),
        Sw("progress", "Müzik ilerleme çubuğu", "Music progress bar", true),
        Sw("flash", "Fener düğmesi", "Flashlight button", true),
        Sw("appicon", "Uygulama simgesi", "App icon", true),
        Sw("clearbtn", "Bildirim sil/aç düğmeleri", "Clear/open buttons", true),
        Sw("anim", "Animasyonlar", "Animations", true),
        Sw("privacy", "Gizlilik modu (içeriği gizle)", "Privacy mode (hide content)", false)
    )
    val seeks = listOf(
        Sk("width", "Genişlik (dp)", "Width (dp)", 100, 300, 140),
        Sk("height", "Yükseklik (dp)", "Height (dp)", 28, 60, 34),
        Sk("yoff", "Üstten boşluk (dp)", "Top offset (dp)", 0, 60, 8),
        Sk("radius", "Köşe yuvarlaklığı (dp)", "Corner radius (dp)", 8, 30, 20),
        Sk("opacity", "Saydamlık (%)", "Opacity (%)", 30, 100, 100),
        Sk("timeout", "Gösterim süresi (sn)", "Display time (s)", 2, 15, 5),
        Sk("animms", "Animasyon süresi (ms)", "Animation time (ms)", 100, 800, 300),
        Sk("textsize", "Yazı boyutu (sp)", "Text size (sp)", 10, 18, 12)
    )
    val bgColors = intArrayOf(0xFF000000.toInt(), 0xFF1C1C1E.toInt(), 0xFF0A2540.toInt(), 0xFF3B0A45.toInt(), 0xFF0B3D2E.toInt(), 0xFF5A1010.toInt())
    val fgColors = intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFD60A.toInt(), 0xFF30D158.toInt(), 0xFF64D2FF.toInt(), 0xFFFF9F0A.toInt(), 0xFFFF453A.toInt())

    fun sp(c: Context) = c.getSharedPreferences("ada", Context.MODE_PRIVATE)
    fun b(c: Context, k: String) = sp(c).getBoolean(k, switches.first { it.key == k }.def)
    fun i(c: Context, k: String) = sp(c).getInt(k, seeks.first { it.key == k }.def)
    fun bgIdx(c: Context) = sp(c).getInt("bg", 0).coerceIn(0, bgColors.size - 1)
    fun fgIdx(c: Context) = sp(c).getInt("fg", 0).coerceIn(0, fgColors.size - 1)
    fun bg(c: Context) = bgColors[bgIdx(c)]
    fun fg(c: Context) = fgColors[fgIdx(c)]
    fun blacklist(c: Context): Set<String> =
        (sp(c).getString("black", "") ?: "").split(",", "\n", " ").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
}
