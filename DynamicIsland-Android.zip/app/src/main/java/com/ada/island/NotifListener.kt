package com.ada.island

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifListener : NotificationListenerService() {
    companion object { var instance: NotifListener? = null }

    override fun onListenerConnected() { instance = this }
    override fun onListenerDisconnected() { instance = null }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        if (Prefs.blacklist(this).contains(sbn.packageName)) return
        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        if (title.isEmpty() && text.isEmpty()) return
        val icon = try { packageManager.getApplicationIcon(sbn.packageName) } catch (e: Exception) { null }
        Bus.post?.invoke(Item(sbn.key, sbn.packageName, title, text, icon, n.contentIntent))
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        Bus.remove?.invoke(sbn.key)
    }
}
