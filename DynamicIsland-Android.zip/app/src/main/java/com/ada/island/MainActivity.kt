package com.ada.island

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.widget.*

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun startSvc() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, t("Önce üstte görüntüleme iznini ver", "Grant overlay permission first"), Toast.LENGTH_LONG).show()
            return
        }
        val i = Intent(this, IslandService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    private fun poke() { if (IslandService.running) startSvc() }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val sc = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(32))
        }
        sc.addView(root)
        setContentView(sc)

        root.addView(TextView(this).apply { text = "AdaIsland • Dynamic Island"; textSize = 24f })

        fun btn(txt: String, f: () -> Unit): Button {
            val b = Button(this)
            b.text = txt
            b.setOnClickListener { f() }
            root.addView(b)
            return b
        }

        btn(t("1) Üstte görüntüleme izni", "1) Overlay permission")) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn(t("2) Bildirim erişimi (bildirim + müzik için)", "2) Notification access (notifications + music)")) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        btn(t("3) Diğer izinler (bildirim, telefon)", "3) Other permissions (notifications, phone)")) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.READ_PHONE_STATE), 1)
        }
        btn(t("▶ Adayı başlat", "▶ Start island")) { startSvc() }
        btn(t("■ Durdur", "■ Stop")) { stopService(Intent(this, IslandService::class.java)) }

        root.addView(TextView(this).apply { text = "\n" + t("Ayarlar", "Settings"); textSize = 20f })

        for (sw in Prefs.switches) {
            root.addView(Switch(this).apply {
                text = t(sw.tr, sw.en)
                isChecked = Prefs.b(this@MainActivity, sw.key)
                setOnCheckedChangeListener { _, v ->
                    Prefs.sp(this@MainActivity).edit().putBoolean(sw.key, v).apply()
                    poke()
                }
            })
        }

        for (sk in Prefs.seeks) {
            val cur = Prefs.i(this, sk.key)
            val label = TextView(this)
            label.text = t(sk.tr, sk.en) + ": " + cur
            val bar = SeekBar(this)
            bar.max = sk.max - sk.min
            bar.progress = cur - sk.min
            bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(b: SeekBar?, p: Int, fromUser: Boolean) {
                    label.text = t(sk.tr, sk.en) + ": " + (p + sk.min)
                    if (fromUser) Prefs.sp(this@MainActivity).edit().putInt(sk.key, p + sk.min).apply()
                }
                override fun onStartTrackingTouch(b: SeekBar?) {}
                override fun onStopTrackingTouch(b: SeekBar?) { poke() }
            })
            root.addView(label)
            root.addView(bar)
        }

        val bgBtn = Button(this)
        val fgBtn = Button(this)
        fun paint() {
            bgBtn.text = t("Adanın rengi (değiştir)", "Island color (change)")
            bgBtn.setBackgroundColor(Prefs.bg(this))
            bgBtn.setTextColor(Color.WHITE)
            fgBtn.text = t("Yazı rengi (değiştir)", "Text color (change)")
            fgBtn.setBackgroundColor(0xFF333333.toInt())
            fgBtn.setTextColor(Prefs.fg(this))
        }
        bgBtn.setOnClickListener {
            Prefs.sp(this).edit().putInt("bg", (Prefs.bgIdx(this) + 1) % Prefs.bgColors.size).apply(); paint(); poke()
        }
        fgBtn.setOnClickListener {
            Prefs.sp(this).edit().putInt("fg", (Prefs.fgIdx(this) + 1) % Prefs.fgColors.size).apply(); paint(); poke()
        }
        paint()
        root.addView(bgBtn)
        root.addView(fgBtn)

        root.addView(TextView(this).apply {
            text = "\n" + t("Engellenen uygulamalar (paket adı, virgülle):", "Blocked apps (package names, comma separated):")
        })
        root.addView(EditText(this).apply {
            setText(Prefs.sp(this@MainActivity).getString("black", ""))
            hint = "com.example.app, com.other.app"
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(x: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(x: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(e: Editable?) {
                    Prefs.sp(this@MainActivity).edit().putString("black", e?.toString() ?: "").apply()
                }
            })
        })
    }
}
